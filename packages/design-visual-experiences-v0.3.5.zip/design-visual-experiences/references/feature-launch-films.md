# Feature launches and product-demo films

Use this for motion-led announcements, feature launches and product demos. Choose the audience's new understanding or capability before borrowing a visual style. The methods below are original adaptations of inspected Higgsfield footage; [source observations and inspection limits](research/higgsfield-motion.md) remain separate. They are not a universal formula, a measured conversion result or recovered production code.

**Read what fits:** [Title-to-image handoff](#title-to-image-handoff) · [Illustration assembly and character performance](#illustration-assembly-and-character-performance) · [Offer mechanics and replenishment](#offer-mechanics-and-replenishment) · [Exploration before fidelity](#exploration-before-fidelity) · [Read motion at native cadence](#read-motion-at-native-cadence) · [Parallel action and return of control](#parallel-action-and-return-of-control) · [Story and agency](#story-and-agency) · [Hooks and proof](#hooks-and-proof) · [Pacing and readable-hold-time](#pacing-and-readable-hold-time) · [Object continuity and movement](#object-continuity-and-movement) · [Composition and finishing](#composition-and-finishing) · [Generated assets and controlled graphics](#generated-assets-and-controlled-graphics) · [Branding and calls to action](#branding-and-calls-to-action).

## Story and agency

Choose what the viewer gains: **direct the world**, **finish precisely**, or **delegate and return**. Cinema Studio makes a scene manipulable; Layers alternates generated changes with manual finishing; Dots converts research into a blueprint and then an app. These are distinct roles for the human, with different emotional payoffs. A reclining user receiving a notification fits delegated work but may misrepresent a tool whose appeal is hands-on control.

Keep one continuing example and make each operation answer a need left by the previous one. For a workflow film, research → decision → deliverable → next action is usually clearer than unrelated feature panels. Close a phase with a visible artifact before introducing another responsibility. If scenes can be shuffled without loss, check whether the film is intentionally a capability montage or accidentally an unordered demo.

**Original worked combination:** A campaign-planning demo follows one real brief into research cards, a selected insight, a plan, and a finished creative. Share `briefId`, `selectedEvidenceId` and `deliverableId` across scenes; derive display states from one authored clock. The selected research card becomes a cited row in the plan. The plan's chosen direction becomes the hero creative. The final hold shows an action the real product supports. Use [composition guidance](compositions.md) for state and coordinate ownership; avoid separate lookalike objects whose content diverges at a handoff. This is an implementation proposal, not Higgsfield's code.

Expose phase durations, selected item, output count and hero hold. Changing the chosen item should update every later appearance. Removing an unnecessary feature scene should preserve the central story; removing the decision that motivates the result should visibly break it.

## Parallel action and return of control

For a delegated-work film, intercut the machine's progress with a familiar human activity: an agent edits while the user makes coffee, for example. Give both tracks a progression and reunite them around a usable result. The September 30 computer-use film cuts from organized folders to seating a coffee pot, then returns to editing after the machine is switched on. Later the exported file precedes the person's return. This makes waiting tangible; edited parallel action does not prove literal execution time.

Cut on completed actions rather than a fixed alternation interval. Preserve one job and its output identity across both tracks. Introduce a repair feature when an obstacle motivates it: a continuity problem calls for a bridging shot; a cleanup problem calls for a localized correction. The human activity must advance rather than serve as unrelated lifestyle filler.

**Original implementation:** derive both tracks from one authored clock, with named cut points tied to visible action phases. Keep `jobId` and `outputId` stable. A shared `controlOwner` state—agent, returning, human—drives cursor treatment, completion label and enabled controls. First reveal and settle the actual output, then retire the completion label and return control. In the reference, the blue cursor becomes an ordinary pointer after the file and Done appear; the exact renderer is unknown. In a live demo, use actual completion events instead of the film's authored timer.

Tune human cut points, phase durations, output settling time, completion hold and control-return time. Scrub before/after each cut: unresolved actions, duplicate cursors, premature Done labels or a different output identity break causality. Check animated counters through their settled state: this film briefly shows 99% at 72s but settles at 91% shortly afterward. Neither value is independently verified consumption.

A continuing human afterbeat can sit under the closing availability line. Keep the text stable and contrast sufficient; the joke must not consume the only readable interval. Choose a quiet card if the scene competes with the message. These are adaptations; see [source and exact inspection limits](research/higgsfield-motion.md#computer-use-extension--september-30).

## Hooks and proof

Start with a meaningful state, event or specific ambition. A relevant unresolved action creates a question; a visible transformation provides proof; a concrete unfinished job supplies motivation. Cinema Studio opens with an active rower and a threat developing behind him, then connects that cinematic image to control of the scene. A shocking opening that never reconnects to the capability wastes its narrative setup.

Measure first visible action, first understandable promise and first credible proof separately. An opening title or quiet image can be intentional; an empty lead-in needs a reason. Inspect the delivered file at time zero and normal speed, including player/loading behavior, rather than assuming the timeline preview represents the opening.

Show enough input and operation to make the result credible. Preserve the example's identity and exact factual claims: an electric-vehicle brief must not silently become a handheld-console website. Mark conceptual UI when it is not actual product behavior. Spectacular output alone demonstrates aspiration, not control of the production workflow.

## Offer mechanics and replenishment

For an offer-led launch, explain the transaction before adding urgency. In the Seedance API film, a balance drains, pauses, then refills as coins cross its rim. The main cashback claim stays in place while amount, reservoir height, color and arrows explain the change. The later total-pool countdown is a separate claim. See [observed phases and limits](research/higgsfield-motion.md#seedance-api--offer-mechanics).

Combine the existing [particles-to-counter mechanism](patterns/motion.md#collect-to-destination) with an anchored reservoir and a depletion/replenishment story.

**Original implementation:** derive an illustrative `balance(t)` from one authored clock with depletion, low hold, replenishment and confirmation phases. Share that value across the formatted number and reservoir geometry; give color/glint their own settling intervals. Keep the base and label anchored, and clamp a minimum height so small values remain readable. Schedule the leading coin's rim crossing at the first increase: visible arrival supplies a cause for the changing number. A particle shower unrelated to the value would weaken the explanation. These are reconstruction choices, not recovered source code; the reference's height and underbar are not calibrated proportional charts.

Expose starting amount, low amount, returned amount, phase durations, minimum height and arrival time. Derive state from time rather than accumulating deposits per rendered frame, so seeking cannot double-credit the balance. Check immediately before contact, on the first increase, at the maximum and during departure. Also test partial returns, zero balance and longer labels. Let the result settle before moving the explanatory object away; keep decorative rotation or glints subordinate to the number.

In a live product, actual verified events own the balance. In a film, distinguish illustrative figures from factual claims and verify promotional terms separately. A precise animated countdown is not evidence of live scarcity. Preserve a distinct `poolRemaining` from an individual's `balance`; do not let visual continuity imply those amounts are interchangeable.

## Exploration before fidelity

When a product separates trying alternatives from finishing a chosen result, give those decisions different visual operations. Preview Mode cycles through draft takes with the preview badge intact, enlarges a chosen take, then uses a separate render control and sweeping transformation. Enlargement selects the subject of attention; the later transformation communicates fidelity. See [observations and comparison limits](research/higgsfield-motion.md#preview-mode--native-cadence-review).

**Original implementation:** keep `selectedTakeId` independent of `qualityTier`. Exploration changes the take; promotion preserves the choice and changes its quality state. Separate geometric arrival, distortion decay, image settling, badge confirmation and readable hold. The reference's card reaches its approximate bounds before the colored perimeter clears; one shared duration would erase that distinction. Keep controls stable enough to connect action and response. In live UI, confirmation follows actual completion, not an authored timer.

For a resolution comparison, align action phase, crop and display size before assessing detail. The reference's unequal overlapping cards emphasize the final result but do not constitute a controlled fidelity benchmark. A sweep can conceal differences in framing or action: verify correspondence rather than treating the effect as proof. Expose take selection, card bounds, settling duration, sweep progress and confirmation time; test a changed take, interrupted render and mismatched crop.

## Read motion at native cadence

When studying motion references, use sparse storyboards to locate events, then inspect consecutive source frames through the full event and its neighboring holds. Preserve frame indices and presentation timestamps; do not interpolate extra frames as evidence. At 24 fps a one-second sample skips 23 positions, enough to miss the entire handoff. Use larger short sequences and native crops for small geometry, masks and type. Track extraction, viewed frames, resolution, playback and listening separately.

Read position, scale, rotation, deformation, opacity and occlusion in each frame's own coordinates. Compare displacement over actual time to distinguish acceleration, settling and a hold; verify apparent bounce against stable landmarks. A dense review of Preview Mode corrected an initial impression of title bobbing: the main lockup settles while the footage continues behind it. The card transition instead visibly ripples as it shrinks. Do not infer the same motion rule for both.

Review normal-speed and slowed playback for rhythm when temporal media is actually available. Still sequences support trajectories and timing, not certified audiovisual feel. Label that limitation if playback is unavailable. Exact easing functions or spring constants require source code or an explicitly fitted reconstruction; rendered frames alone do not reveal the original implementation.

## Pacing and readable-hold-time

Separate event rate, motion rate, reading rate and recognition time. Fast repetition can communicate abundance without asking the viewer to read every item. Then select one item, stabilize it and let it carry the explanation. A useful sequence is **one → many → one**: orientation, breadth, appreciation. It is an option, not a required shot count.

In the inspected Dots stack, cards briefly change at roughly two-frame intervals; selected evidence receives a readable state. The 25.6-second GPT-5.6/Supercomputer film gives one hero output about 6.7 seconds after the grid. Borrow the allocation of attention, not those durations as presets.

Author orientation, action, confirmation and appreciation as distinct timing concerns. Compress travel between meaningful states while preserving the important result. Count reading time after blur, clipping and motion stop materially competing with the copy: Layers' final card occupies about 3.09 seconds but offers about 2.79 seconds of comfortably crisp reading in the reviewed rendition. Tune with the actual sentence, crop and viewing size.

Expose arrival duration, stagger, settling interval, crisp hold and departure. Test a longer headline and a narrower crop. If the message becomes unreadable, recompose or extend the hold instead of accelerating every other event. Use [production timing and sound](production.md); frame strips alone cannot establish rhythm or audiovisual synchronization.

## Illustration assembly and character performance

For an illustration-to-animation demo, let separate parts assemble into a recognizable character, then demonstrate a few distinct actions. Keep the room or grid stable so viewers can read local changes. In the [Higgsfield illustration demo](research/higgsfield-motion.md#illustration-rig--assembly-and-performance), limbs and props appear before bodies connect; later cup lifts, mop strokes and stick tosses alternate with quieter poses. This is edited process storytelling, not proof of uninterrupted live generation.

**Original reconstruction:** build one canonical rig with named parts, rest transforms, pivots, parents and hidden joint overlap. Use separate `revealProgress`, `actionPhase` and `secondaryPhase` controls: assembly determines visibility; action moves the established rig; accents follow their own short lifetimes. Reuse [object continuity](#object-continuity-and-movement) and [measured pose fitting](patterns/motion.md#measured-joint-motion), rather than regenerating the entire character at each phase.

Give each action preparation, travel, a readable pose, return and a quiet interval. Offset primary gestures across characters; small notes, reaction strokes and contact marks should support the current action. Tune phase offsets, amplitude and hold duration before adding more movement. A cup inherits the wrist transform while held. A tossed stick changes to world-space ownership at release, preserving its visible transform; catch or reattachment is a distinct event. Do not mistake an offscreen interval for evidence of a physically continuous return.

Assign masks per part. A braid or mop that crosses a panel gutter needs a shared overlay or an explicit cross-panel mask; indiscriminate card clipping destroys the intended connection. Keep a stable scene coordinate system beneath those overlays. For a held-drawing style, an optional quantized illustration clock can run independently of a continuous UI clock. The source shows a request for 30fps export with 15fps drawing updates; the request alone does not verify the implemented cadence.

Inspect native-resolution extreme poses for uncovered elbows, wrists and clothing edges. Small white wedges visible in the reference motivate overlap checks, not a claim of flawless finishing or a known root cause. Test attached-prop contact, release-frame continuity, masks and the actual exported loop seam. The source's 13-second presentation starts with fragments and ends assembled; a requested inner loop is not proof that the outer film loops. Keep the final deliverable legible long enough for the audience; an in-product download control is different from a public CTA.

## Object continuity and movement

Choose an invariant the viewer can track: identity, selected content, position, action phase, label or screen direction. A change of scale can change an object's role: Cinema Studio's image becomes a miniature set around 3.17–3.46 seconds, then a cast actor enters the set before the camera enters the performance. The movement explains a relationship.

For a shared-object handoff, define source and destination bounds, coordinate space, parent transform, crop/mask and layer order. Keep one owner of the transferred object during overlap; switch ownership only when geometry and visible content agree. A shared clock coordinates camera, object and label. See [transition QA](transition-qa.md) and the existing [persistent shape](patterns/motion.md#persistent-shape) and [world-in-object reveal](patterns/camera.md#reveal-world-in-object) mechanisms.

Choose the operation for its meaning: multiplication for breadth, a registered wipe for comparison, collection into a file for delivery, separation into parts for editability. Hard cuts between stable views can demonstrate angles more clearly than a morph. Do not independently animate every layer when one movement should define the event.

Inspect immediately before, at and after the handoff: wrong identity, doubled objects, crop jumps, early labels, missed contact and reversed occlusion. Match action phases when comparing reference clips; equal timestamps need not show equivalent events. Rendered motion does not reveal an exact spring constant, easing curve or original renderer. Fit and test your own curve when useful; call it synthesis.

## Title-to-image handoff

When a launch needs both a readable name and an image worth inspecting, give them consecutive moments of emphasis. In the [Seedream portrait announcement](research/higgsfield-motion.md#seedream--title-to-image-handoff), a centered title settles over a dimmed portrait, then shrinks and moves below the eye as the image brightens. Partner marks arrive later above it. The title remains visible while the eye, glass glints and gentle image enlargement carry the next phase. This is an availability announcement, not a demonstrated product workflow.

**Original reconstruction:** keep the two-line title as one screen-space block, separate from the hero's crop/push-in parent. Coordinate title bounds, image brightness and partner reveal from one authored clock, with independent settling intervals. Reserve a focal exclusion region around the eye or product detail; move the title outside it before the appreciation hold. Scope travel blur to the moving graphic so the revealed detail stays clear. Reuse [object continuity](#object-continuity-and-movement) for identity and [composition guidance](compositions.md) for transform ownership.

Expose center/docked bounds, focal region, contrast change, brand delay and crisp holds. Test a longer name and alternate crop: recompute the destination rather than copying the reference's bottom position. Check the readable center, maximum blur, settled dock and final branded state. Keep settled labels fixed while the image moves. The source's two-second white availability card is measured evidence, not a universal reading-time target; test the actual copy at export size. No source easing, renderer or audiovisual rhythm was established.

## Composition and finishing

Prepare space before the next message. Layers lowers a portrait group around 33.8 seconds before requesting its heading at 34.45. This makes typography part of the composition rather than a late overlay. Use deliberate focus changes: enlarge the relevant control or selected evidence, then give the completed output more area and retire used controls.

Keep generated work and manual finishing distinct when the product supports both. A subtitle being typed, glasses dragged into place or a sticker nudged communicates intentional control. Color can identify a selection or target group without being the requested output color; labels and pixels must agree about that role.

Review causal details: click before response, badge after the visible state changes, object behind the correct foreground edge, pose/contact reaching the intended phase before a cut. Check exact spelling and input/output identity at native resolution. A recognizable character is not proof that all unselected pixels stayed unchanged; compare those regions when claiming a localized edit.

Let material and lighting support the chosen world. Establish which layers are photographic, tactile, graphic or spatial; adding every expensive-looking treatment does not produce coherent art direction. Use [principles](principles.md) for the overall visual language and [diagnosis](diagnosis.md) for the largest visible weakness.

## Generated assets and controlled graphics

Separate **content creation**, **film assembly** and **orchestration**. An agent invoking a model or writing After Effects expressions does not imply every pixel was rendered in code. An AI product badge does not establish that its outer announcement film was generated entirely by that model. Inspected production claims include storyboards, paintovers, performance references, selection/editing and specialist finishing; original editable projects were not inspected.

For new work, choose the method per layer:

| Layer | Preserve | Practical approach |
|---|---|---|
| Cinematic assets | Subject identity, framing, action, usable entry/exit states | Filming, generation, 3D or a hybrid; select takes for neighboring shots |
| Product UI and evidence | Real labels, data and supported state changes | Capture or faithful designed UI, with conceptual behavior identified |
| Type, logos and CTA | Exact wording, alignment and legible holds | Controlled graphic layers in motion software or code |
| Comparisons, grids and transfers | Registration, shared geometry and timing | Deterministic composition; keep one source of state |
| Sound and final edit | Intelligibility, emphasis and synchronization | A separate listening and editorial pass on the export |

These are original production recommendations. Plan difficult handoffs before generating assets, and retain masks/depth only where the selected workflow can use them. A beautiful isolated frame may have no usable transition. Do not bundle third-party footage, full prompts or implementations into a new deliverable without appropriate rights. Link references and preserve attribution; use original assets for new work.

## Branding and calls to action

Keep a recognizable grammar while allowing the example's world to vary. Fix type roles, logo handling, status meanings and control behavior; vary imagery, genre and campaign palette deliberately. Distinguish the software brand, partner identity and fictional customer's output. Dots retains role markers across dark source posts, white UI and a purple customer app. Project branding always overrides the reference palette.

Choose the ending's job: availability/destination, a usable deliverable, a human decision, recurring work, submission or brand recall. Dots closes with a lockup, not an observed “Try now” instruction. A fictional watch site's preorder is distinct from the surrounding integration announcement's availability. Do not invent a CTA when describing a reference or promise an action the real product cannot perform.

Give the ending enough quiet and readable time for its actual copy at feed size. A source's small type or short card is not evidence of conversion effectiveness. Review the final encoded crop and player controls. For a brief, adapt: “Show [audience] completing [one real job]. Make [transformation] visible through [persistent object], use [operation] to explain it, let [proof] register, then offer [supported next action]. Preserve [brand and factual invariants].”
